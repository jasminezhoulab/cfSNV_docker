#' @useDynLib cfSNV, .registration = TRUE
NULL
#' @importFrom Rcpp sourceCpp
NULL
#' @importFrom Rcpp evalCpp
NULL
#' @import Rcpp
NULL
